import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class StudentManager {
//-------<Singleton>---------------------------------------
    private static StudentManager instance = null;

    public static StudentManager getInstance()
    {
        if(instance == null)
            instance = new StudentManager();

        return instance;
    }

//-------<생성자>---------------------------------------
    private StudentManager() {
        studentList = new LinkedList<Student>();
    }

//-------<데이터>---------------------------------------
    private List<Student> studentList;

//-------<Create>---------------------------------------
    public void C(Student student) {

        studentList.add(student);

        System.out.println("학생 추가 완료");
    }


//-------<Read>---------------------------------------
    public List<Student> R(String name) {

        List<Student> students = new ArrayList<Student>();

        for (Student student : studentList) {
            if(student.getName().equals(name)) {
                students.add(student);
            }
        }
        return students;
    }

    public List<Student> R(int score) {

        List<Student> students = new ArrayList<Student>();

        for (Student student : studentList) {
            if(true) {
                students.add(student);
            }
        }
        return students;
    }

    public List<Student> findAll() {
        return studentList;
    }

//-------<Update>---------------------------------------
    public void U(String name, String changeName) {
        List<Student> students = R(name);

        for (Student student : students) {
            student.setName(changeName);
        }
    }

    public void U(int score) {
        List<Student> students = R(score);
    }
//-------<Delete>---------------------------------------
    public void D(int index) {
        studentList.remove(index);
    }

    public void D(String name) {
        List<Student> students = R(name);
        studentList.removeAll(students);
    }
}
