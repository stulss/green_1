public class Main {
    public static void main(String[] args) {
        MainUpdate Main = new MainUpdate();

        for(int i = 0 ; i < 4 ;++i)
            Main.render();
    }
}
